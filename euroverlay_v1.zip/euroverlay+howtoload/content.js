let openLayersMap;
let euFeature = null;
let url__ = "libs/eu_border.geojson";
let loadCSS_done=false;
let createMapContainer_done=false;
let loadOpenLayers_done=false;
let topLeftMenuFunctionalities_done=false;

function loadCSS() {
    const style = document.createElement('style');
    style.textContent = `
        /* General Styles */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Map container */
        #map {
            width: 100vw;
            height: 100vh;
        }

        /* Info Panel */
        #infoPanel {
            position: fixed;
            top: 0;
            left: 0;
            width: 0;
            height: 100%;
            background-color: white;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            transition: width 0.3s ease;
            z-index: 1000;
        }

        /* Info Panel Header */
        #infoPanelHeader {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            display: flex;
            justify-content: flex-end;
            background: rgba(255, 255, 255, 0.5);  /* Transparent white background */
            padding: 10px;
            box-sizing: border-box;
            z-index: 1; /* Ensure it's above the image */
        }

        #closeInfoPanel {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
        }

        /* Info Panel Content */
        #infoPanelContent {
            display: none;
            padding-top: 50px; /* Add padding to ensure the content doesn't overlap with the header */
        }

        /* Info Panel Image */
        #infoPanelImage {
            width: 100%;
            height: 200px;
            background-color: #ddd;
            background-size: cover;
            background-position: center;
            position: relative;
            z-index: 0; /* Ensure it's below the header */
        }

        /* Info Panel Title */
        #infoPanelTitle {
            padding: 16px 24px;
            font-size: 22px;
            font-family: Roboto;
        }

        hr{
            margin:0;
        }

        /* Info Panel Description */
        #infoPanelDescription {
            padding: 0px 24px 24px;
            font-size: 14px;
            font-family: Roboto;
            color: black;
            line-height: 1.5;
        }

        /* Info Panel Buttons */
        #infoPanelButtons {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 20px;
        }

        .infoButton {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 14px;
            border-radius: 4px;
            cursor: pointer;
            flex: 1 1 calc(50% - 10px); /* Two buttons per row */
            text-align: center;
        }

        .infoButton:hover {
            background-color: #0056b3;
        }

        /* Top Left Button */
        #topLeftButton {
            position: fixed;
            top: 10px;
            left: 40px;
            width: 40px;
            height: 40px;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 0px;
            cursor: pointer;
            z-index: 1001;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0.4px 1px rgba(0, 0, 0, 0.75);
            transition: transform 0.3s ease;
        }

        #topLeftButton img {
            width: 24px;
            height: 24px;
        }

        /* Top Left Menu */
        #topLeftMenu {
            position: fixed;
            top: 10px;
            left: 100px;
            width: 0;
            height: 0px;
            background-color: #fff;
            border: 1px solid #ddd;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            z-index: 1001;
            transition: width 0.3s ease;
        }

        #topLeftMenu ul {
            list-style: none;
            padding: 10px;
            margin: 0;
        }

        #topLeftMenu ul li {
            padding: 10px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.2s ease;
        }

        #topLeftMenu ul li:hover {
            background-color: #f1f1f1;
        }

        /* The switch - the box around the slider */
        .switch {
          position: relative;
          display: inline-block;
          width: 50px;
          height: 28px;
        }
        
        /* Hide default HTML checkbox */
        .switch input {
          opacity: 0;
          width: 0;
          height: 0;
        }
        
        /* The slider */
        .slider {
          position: absolute;
          cursor: pointer;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background-color: #ff7070;
          -webkit-transition: .1s;
          transition: .1s;
          border-radius: 15px;
        }
        
        .slider:before {
          position: absolute;
          content: "";
          height: 20px;
          width: 20px;
          left: 4px;
          bottom: 4px;
          background-color: white;
          -webkit-transition: .1s;
          transition: .1s;
          border-radius: 10px;
        }
        
        input:checked + .slider {
          background-color: #2178f3;
        }
        
        input:focus + .slider {
          box-shadow: 0 0 1px #1e4fd6;
        }
        
        input:checked + .slider:before {
          -webkit-transform: translateX(22px);
          -ms-transform: translateX(22px);
          transform: translateX(22px);
        }
        
        /* Rounded sliders */
        .slider.round {
          border-radius: 24px;
        }
        
        .slider.round:before {
          border-radius: 50%;
        }    
    `;
    document.head.appendChild(style);
    loadCSS_done=true;
}

function createMapContainer() {
    const mapDiv = document.createElement('div');
    mapDiv.id = 'map';
    document.body.appendChild(mapDiv);

    // Info panel container
    const infoPanel = document.createElement('div');
    infoPanel.id = 'infoPanel';
    infoPanel.innerHTML = `
        <div id="infoPanelHeader">
            <button id="closeInfoPanel">✖</button>
        </div>
        <div id="infoPanelContent">
            <div id="infoPanelImage"></div>
            <h1 id="infoPanelTitle"></h1>
            <hr><br>
            <p id="infoPanelDescription"></p>
            <div id="infoPanelButtons">
                <button class="infoButton">wip</button>
                <button class="infoButton">wip</button>
                <button class="infoButton">wip</button>
                <button class="infoButton">wip</button>
                <button class="infoButton">wip</button>
                <button class="infoButton">wip</button>
                <button class="infoButton">wip</button>
                <button class="infoButton">wip</button>
            </div>
        </div>
    `;
    document.body.appendChild(infoPanel);

    // Top left button
    const topLeftButton = document.createElement('div');
    topLeftButton.id = 'topLeftButton';
    topLeftButton.innerHTML = `
        <img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="Menu">
    `;
    document.body.appendChild(topLeftButton);

    //fonts 

    function loadFonts() {
        const preconnect1 = document.createElement('link');
        preconnect1.rel = 'preconnect';
        preconnect1.href = 'https://fonts.googleapis.com';
        document.head.appendChild(preconnect1);
    
        const preconnect2 = document.createElement('link');
        preconnect2.rel = 'preconnect';
        preconnect2.href = 'https://fonts.gstatic.com';
        preconnect2.crossOrigin = 'anonymous';
        document.head.appendChild(preconnect2);
    
        const fontLink = document.createElement('link');
        fontLink.rel = 'stylesheet';
        fontLink.href = 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap';
        document.head.appendChild(fontLink);
    }
    loadFonts();

    
    // Top left menu
    const topLeftMenu = document.createElement('div');
    topLeftMenu.id = 'topLeftMenu';
    topLeftMenu.innerHTML = `
        <br>
        <ul>
            <p style="color: red; font-size: 14px; text-align: right">Bonaire is not part of the EU. Map is bugged in that place.</p><br>
            <hr>
            <div style="width:175px; margin-left:8.5px; float:left">
                <center>
                <p style="font-size: 16px; font-family: Inter, sans-serif; font-optical-sizing: auto; font-weight: 338; margin:8.5px">Euroverlay</p>
                <label for="addonToggleSwitch" class="switch">
                    <input type="checkbox" id="addonToggleSwitch">
                    <span class="slider"></span>
                </label>
                </center>
            </div>
            <div style="width:175px; margin-left:8.5px; float:left">
                <center>
                <p style="font-size: 16px; font-family: Inter, sans-serif; font-optical-sizing: auto; font-weight: 338; margin:8.5px">Include all overseas</p>
                <label for="overseasToggleSwitch" class="switch">
                    <input type="checkbox" id="overseasToggleSwitch">
                    <span class="slider" id="overseasToggleSlider"></span>
                </label>
                <p style="font-size: 16px; font-family: Inter, sans-serif; font-optical-sizing: auto; font-weight: 338; margin:8.5px">(Detailed)</p>
                </center>
            </div>
            <div style="width:175px; margin-left:8.5px; float:left">
                <center>
                <p style="font-size: 16px; font-family: Inter, sans-serif; font-optical-sizing: auto; font-weight: 338; margin:8.5px">Include potential MS</p>
                <label for="potentialMembersToggleSwitch" class="switch">
                    <input type="checkbox" id="potentialMembersToggleSwitch">
                    <span class="slider" id="potentialMembersToggleSlider"></span>
                </label>
                </center>
            </div>
            <!--
            <li>Change Colors</li>
            <li>outer border type - solid/dotted</li>
            <li>switch na napis European Union</li>
            <li>European Union font size</li>
            <li>set to default</li>
            <li>refresh button</li>
            <li>learn more about the eu overseas</li>
            <li>info (dac tu tez info ze bonaire is bugged)</li>
            -->
        </ul>
    `;
    document.body.appendChild(topLeftMenu);

    // Add event listeners <---------------------------------------------------------------------
    document.getElementById('closeInfoPanel').addEventListener('click', closeInfoPanel);
    document.getElementById('addonToggleSwitch').addEventListener('change', topLeftMenuFunctionalities);
    document.getElementById('addonToggleSwitch').addEventListener('change', toggleViewportVisibilityWaiter);
    topLeftButton.addEventListener('click', toggleTopLeftMenu);

    //most of the switches etc
    document.getElementById('overseasToggleSwitch').addEventListener('change', overseasToggleSwitchFunction);
    document.getElementById('potentialMembersToggleSwitch').addEventListener('change', potentialMembersToggleSwitchFunction);

    createMapContainer_done=true;
}
function toggleViewportVisibilityWaiter(){
    setTimeout(() => {
        toggleViewportVisibility();
        console.log("done");
    }, 100);
}
function topLeftMenuFunctionalities(){
    //functionalities - not here
    const addonToggleSwitch = document.getElementById('addonToggleSwitch');

    const potentialMembersToggleSwitch = document.getElementById('potentialMembersToggleSwitch');
    const potentialMembersToggleSlider = document.getElementById('potentialMembersToggleSlider');

    const overseasToggleSwitch = document.getElementById('overseasToggleSwitch');
    const overseasToggleSlider = document.getElementById('overseasToggleSlider');

    if(addonToggleSwitch.checked){
        console.log("main switch checked? "+addonToggleSwitch.checked);
        //bring colors back
        //change this to the classes later for optimalization <------------------------------
        potentialMembersToggleSlider.style.backgroundColor = "#ff7070";
        overseasToggleSlider.style.backgroundColor = "#ff7070";
    }else{
        //all functionalities should be turned to gray and off here
        //change this to the classes later for optimalization <------------------------------
        potentialMembersToggleSwitch.checked = false;
        potentialMembersToggleSlider.style.backgroundColor = "#a3a3a3";
        initMap(url__);
        overseasToggleSwitch.checked = false;
        overseasToggleSlider.style.backgroundColor = "#a3a3a3";
    }
    topLeftMenuFunctionalities_done=true;
}
function potentialMembersToggleSwitchFunction(){
    const potentialMembersToggleSwitch = document.getElementById('potentialMembersToggleSwitch');
    const potentialMembersToggleSlider = document.getElementById('potentialMembersToggleSlider');
    const overseasToggleSwitch = document.getElementById('overseasToggleSwitch');
    const overseasToggleSlider = document.getElementById('overseasToggleSlider');
    if(addonToggleSwitch.checked){
        if(potentialMembersToggleSwitch.checked){
            initMap('potential_members.geojson');
            potentialMembersToggleSlider.style.backgroundColor = "#2178f3";
            overseasToggleSlider.style.backgroundColor = "#ff7070";
            overseasToggleSwitch.checked = false;
        }
        else{
            initMap(url__);
            potentialMembersToggleSlider.style.backgroundColor = "#ff7070";
        }
    }else potentialMembersToggleSwitch.checked = false;
}
function overseasToggleSwitchFunction(){
    const overseasToggleSwitch = document.getElementById('overseasToggleSwitch');
    const overseasToggleSlider = document.getElementById('overseasToggleSlider');
    const potentialMembersToggleSwitch = document.getElementById('potentialMembersToggleSwitch');
    const potentialMembersToggleSlider = document.getElementById('potentialMembersToggleSlider');
    if(addonToggleSwitch.checked){
        if(overseasToggleSwitch.checked){
            initMap('overseas_detailed.geojson');
            overseasToggleSlider.style.backgroundColor = "#2178f3";
            potentialMembersToggleSlider.style.backgroundColor = "#ff7070";
            potentialMembersToggleSwitch.checked = false;
        }
        else{
            initMap(url__);
            overseasToggleSlider.style.backgroundColor = "#ff7070";
        }
    }else overseasToggleSwitch.checked = false;
}

function toggleTopLeftMenu() {
    const menu = document.getElementById('topLeftMenu');
    const isOpen = menu.style.width === '584px';

    if (isOpen) {
        menu.style.height = '0';
        menu.style.width = '0';
    } else {
        menu.style.width = '584px';
        menu.style.height = '480px';
    }
}

function closeInfoPanel() {
    const infoPanel = document.getElementById('infoPanel');
    const menu = document.getElementById('topLeftMenu');
    const menuBtn = document.getElementById('topLeftButton');
    const zoomBtns = document.getElementsByClassName('ol-zoom');
    infoPanel.style.width = '0';
    menu.style.left = "100px";
    menuBtn.style.left = "40px";
    for (let i = 0; i < zoomBtns.length; i++) zoomBtns[i].style.margin = "0";
    document.getElementById('infoPanelContent').style.display = 'none';
}

function loadOpenLayers() {
    const olCSS = document.createElement('link');
    olCSS.rel = "stylesheet";
    olCSS.href = chrome.runtime.getURL('libs/ol.css'); // Correct path for OpenLayers CSS in extension
    document.head.appendChild(olCSS);

    const olScript = document.createElement('script');
    olScript.src = chrome.runtime.getURL('libs/ol.js'); // OpenLayers JS path
    olScript.onload = () => {
        if (typeof ol === 'undefined') {
            console.error('OpenLayers did not load correctly.');
        } else {
            initMap(url__);
        }
    };
    document.body.appendChild(olScript);
    loadOpenLayers_done=true;
}

function initMap(url1) {
    let url1_=url1;
    console.log("Initializing map with url - ", url1_);

    const viewports = document.querySelectorAll('.ol-viewport');

    viewports.forEach(viewport => {
        if (viewport) viewport.remove();
    });

    const googleMapsLayer = new ol.layer.Tile({
        source: new ol.source.XYZ({
            url: 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        }),
        title: 'BaseTileLayer' // Set a recognizable title
    });

    const vectorSource = new ol.source.Vector({
        url: chrome.runtime.getURL(url1_), // GeoJSON for EU border
        format: new ol.format.GeoJSON()
    });

    const vectorLayer = new ol.layer.Vector({
        source: vectorSource,
        style: new ol.style.Style({
            stroke: new ol.style.Stroke({
                color: 'rgba(38, 38, 222, 0.16)',
                width: 1.8
            }),
            fill: new ol.style.Fill({
                color: 'rgba(38, 38, 222, 0.11)'
            })
        }),
        title: 'EUBorders' // Add this line to give the layer a title
    });

    openLayersMap = new ol.Map({
        target: 'map',
        layers: [googleMapsLayer, vectorLayer],
        view: new ol.View({
            center: ol.proj.fromLonLat([20.1239995, 46.0461934]),
            zoom: 4,
            minZoom: 3, // Prevent zooming out too much
            maxZoom: 14 // Prevent zooming in too much
        })
    });

    const labelSource = new ol.source.Vector();
    const labelLayer = new ol.layer.Vector({
        source: labelSource,
        style: createLabelStyle(),
    });
    openLayersMap.addLayer(labelLayer);

    vectorSource.on('change', () => {
        if (vectorSource.getFeatures().length) {
            addCountryLabels(vectorSource.getFeatures(), labelSource);
        }
    });

    openLayersMap.getView().on('change:resolution', () => {
        labelSource.clear();
        const currentZoom = openLayersMap.getView().getZoom();
        if (currentZoom >= 5) {
            addCountryLabels(vectorSource.getFeatures(), labelSource);
        }
        if (euFeature) {
            updateEULabelScale(currentZoom);
        }
    });

    addLargeEULabel();
    setupClickInteraction();
}

function toggleViewportVisibility() {
    const viewports = document.querySelectorAll('.ol-viewport'); // Select all ol-viewport divs

    viewports.forEach(viewport => {
        if (viewport) {
            // Check if the current viewport is visible
            if (viewport.style.display === 'none') {
                // Show the ol-viewport (map content)
                viewport.style.display = 'block';
                
                // Update menu positioning
                const menu = document.getElementById('topLeftMenu');
                const menuBtn = document.getElementById('topLeftButton');
                
                // Adjust menu positioning based on the current viewport state
                menu.style.left = "100px";
                menuBtn.style.left = "40px";
                menu.style.margin = "0px 0px 0px 0px";
                menuBtn.style.margin = "0px 0px 0px 0px";
            } else {
                // Hide the ol-viewport (map content)
                viewport.style.display = 'none';
                
                // Reset menu positioning
                const menu = document.getElementById('topLeftMenu');
                const menuBtn = document.getElementById('topLeftButton');
                
                menu.style.left = "544px";
                menuBtn.style.left = "484px";
                menu.style.margin = "1px 0px 0px 0px";
                menuBtn.style.margin = "1px 0px 0px 0px";
            }
        }
    });
}

function addLargeEULabel() {
    const luxembourgCoordinates = ol.proj.fromLonLat([8.8, 49.0117]);

    euFeature = new ol.Feature({
        geometry: new ol.geom.Point(luxembourgCoordinates),
        name: "European Union",
        description: "Fetching details..."
    });

    const labelStyle = new ol.style.Style({
        text: new ol.style.Text({
            text: 'European Union',
            font: 'bold 14px Roboto',
            fill: new ol.style.Fill({ color: '#000' }),
            stroke: new ol.style.Stroke({ color: '#fff', width: 2 }),
            scale: 1.2
        })
    });

    euFeature.setStyle(labelStyle);

    const labelSource = new ol.source.Vector();
    const labelLayer = new ol.layer.Vector({
        source: labelSource
    });
    labelSource.addFeature(euFeature);

    openLayersMap.addLayer(labelLayer);
}

function updateEULabelScale(zoomLevel) {
    if (!euFeature) return;
    const scale = 1 + (zoomLevel - 4) * 0.2;
    const currentStyle = euFeature.getStyle();
    const textStyle = currentStyle.getText();
    textStyle.setScale(scale);
    euFeature.setStyle(currentStyle);
}

function createLabelStyle() {
    return new ol.style.Style({
        text: new ol.style.Text({
            font: 'bold 18px "Courier New", Courier, monospace',
            fill: new ol.style.Fill({ color: '#000' }),
            stroke: new ol.style.Stroke({ color: '#fff', width: 2 }),
            scale: 1.2
        })
    });
}

function addCountryLabels(features, labelSource) {
    features.forEach((feature) => {
        const geometry = feature.getGeometry();
        const center = ol.extent.getCenter(geometry.getExtent());
        const name = feature.get('name') || 'Unknown Country';

        const labelFeature = new ol.Feature({
            geometry: new ol.geom.Point(center),
            name: name
        });
        labelSource.addFeature(labelFeature);
    });
}

function setupClickInteraction() {
    openLayersMap.on('click', (event) => {
        openLayersMap.forEachFeatureAtPixel(event.pixel, (feature) => {
            const name = feature.get('name');
            openInfoPanel(name, feature.get('description'));
        });
    });
}

function openInfoPanel(name, description) {
    const infoPanel = document.getElementById('infoPanel');
    const contentDiv = document.getElementById('infoPanelContent');
    const imageDiv = document.getElementById('infoPanelImage');
    const titleElem = document.getElementById('infoPanelTitle');
    const descriptionElem = document.getElementById('infoPanelDescription');
    const menu = document.getElementById('topLeftMenu');
    const menuBtn = document.getElementById('topLeftButton');
    const zoomBtns = document.getElementsByClassName('ol-zoom');

    titleElem.textContent = "European Union";
    descriptionElem.innerHTML = "The European Union (EU) is a supranational political and economic union of 27 member states that are located primarily in Europe. The Union has a total area of 4,233,255 km² (1,634,469 sq mi) and an estimated total population of over 449 million. The EU has often been described as a sui generis political entity combining the characteristics of both a federation and a confederation ... <a href='https://en.wikipedia.org/wiki/European_Union' target='blank_'>Read More</a>";
    imageDiv.style.backgroundImage = `url(${chrome.runtime.getURL('images/eu.png')})`;

    // Animate
    infoPanel.style.width = '408px';
    contentDiv.style.display = 'block';

    menu.style.left = "484px";
    menuBtn.style.left = "424px";

    for (let i = 0; i < zoomBtns.length; i++) zoomBtns[i].style.margin = "60px 0px 0px 416px";
}

loadCSS();
createMapContainer();
loadOpenLayers();
topLeftMenuFunctionalities();
function toggleViewportVisibilityAfterSiteLoaded() {
    setTimeout(() => {
        toggleViewportVisibility();
        console.log("done");
    }, 250);
}
if(loadCSS_done && createMapContainer_done && loadOpenLayers_done && topLeftMenuFunctionalities_done) toggleViewportVisibilityAfterSiteLoaded();